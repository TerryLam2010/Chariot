package cn.terrylam.chariot.admin.config;

import cn.terrylam.chariot.base.config.BaseProperties;
import org.springframework.context.annotation.Configuration;


@Configuration
public class AdminProperties extends BaseProperties {
	
	

}
