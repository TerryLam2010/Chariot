package cn.terrylam.chariot.api.config;

import org.springframework.context.annotation.Configuration;

/**
 * 应用spring主配置
 * @author TerryLam
 *
 */
@Configuration
public class ApiConfig {
	
	
}
