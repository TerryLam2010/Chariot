package cn.terrylam.chariot.api.service;

/*import com.alicp.jetcache.anno.CacheRefresh;
import com.alicp.jetcache.anno.CacheType;
import com.alicp.jetcache.anno.Cached;
import org.springframework.stereotype.Service;

*//**
 * @author TerryLam 2019/7/12
 * @version 1.0
 * @description
 **//*
@Service
public class TestService {

    @Cached(cacheType = CacheType.REMOTE)
    @CacheRefresh(refresh = 60)
    public int num(){
        System.out.println("1");
        return 1;
    }
}*/
