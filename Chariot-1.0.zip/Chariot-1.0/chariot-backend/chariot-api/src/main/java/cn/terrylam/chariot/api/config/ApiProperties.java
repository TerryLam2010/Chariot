package cn.terrylam.chariot.api.config;

import cn.terrylam.chariot.base.config.BaseProperties;
import org.springframework.context.annotation.Configuration;


@Configuration
public class ApiProperties extends BaseProperties {
	
	
}
