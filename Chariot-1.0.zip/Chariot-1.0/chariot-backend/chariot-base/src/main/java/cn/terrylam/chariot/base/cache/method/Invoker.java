/**
 * Created on  13-09-24 14:32
 */
package cn.terrylam.chariot.base.cache.method;

/**
 * @author <a href="mailto:areyouok@gmail.com">huangli</a>
 */
public interface Invoker {
    Object invoke() throws Throwable;
}
