package cn.terrylam.chariot.base.util;

/**
 * 常量类
 *
 */
public class Constant {

}
