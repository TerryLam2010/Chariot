/**
 * Created on  13-10-02 23:44
 */
package cn.terrylam.chariot.base.cache.method;

/**
 * @author <a href="mailto:areyouok@gmail.com">huangli</a>
 */
enum EL {
    BUILD_IN, MVEL, SPRING_EL
}
